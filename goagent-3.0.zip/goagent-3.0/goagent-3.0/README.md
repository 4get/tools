goagent 3.2.3 正式版下载 [http://git.io/goa](https://nodeload.github.com/goagent/goagent/legacy.zip/3.0)

## 公告
* 从 3.2.0 以下版本升级的用户，请务必重新上传 GAE/PHP 服务端。

## 讨论区
* https://code.google.com/p/goagent/issues/list

## 文档
* 简易教程 https://github.com/goagent/goagent/blob/wiki/SimpleGuide.md
* 图文教程 https://github.com/goagent/goagent/blob/wiki/InstallGuide.md
* 常见问题 https://github.com/goagent/goagent/blob/wiki/FAQ.md
* 配置介绍 https://github.com/goagent/goagent/blob/wiki/ConfigIntroduce.md
* 五毛观止 https://github.com/goagent/goagent/blob/wiki/SpamList.md
* 更新历史 https://github.com/goagent/goagent/blob/wiki/History.md

## 代码
 * proxy.py https://github.com/goagent/goagent
 * python27.exe https://github.com/goagent/pybuild
 * goagent.exe https://github.com/goagent/taskbar
